
document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("ranking-list");
  const loading = document.getElementById("loading");

  try {
    const response = await fetch("https://flask-ranking-api.replit.app/ranking");
    const data = await response.json();

    loading.style.display = "none";

    data.forEach((item) => {
      const li = document.createElement("li");
      li.innerHTML = \`
        <img src="\${item.imagem_url}" alt="\${item.modelo}" onerror="this.src='https://via.placeholder.com/80'"/>
        <div>
          <strong>#\${item.posicao}</strong> - \${item.modelo}<br />
          <a href="\${item.oferta_url}" target="_blank">Ver Oferta</a>
        </div>
      \`;
      container.appendChild(li);
    });
  } catch (error) {
    loading.innerText = "Erro ao carregar dados do ranking.";
    console.error("Erro:", error);
  }
});
